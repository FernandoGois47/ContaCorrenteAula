from historico import Historico

class EmprestimoLivro:
    def __init__(self, id, status="disponivel"):
        self._id = id
        self._status = status
        self.historico = Historico()

    def emprestar(self):
        if self._status == "disponivel":
            self._status = "emprestado"
            print(f"Livro {self._id} emprestado com sucesso.") 
            self.historico.emprestimo.append("Emprestado {}".format(self._status))
        else:
            print(f"Livro {self._id} não está disponível para empréstimo.")  

    def devolver(self):
        if self._status == "emprestado":
            self._status = "disponivel"
            print(f"Livro {self._id} devolvido com sucesso.")  
        else:
            print(f"Livro {self._id} já está aqui, ué?!.")  
from emprestimo import EmprestimoLivro
from aluno import Aluno
# from historico import Historico
from livros import Livros
from funcionario import Funcionario

aluno = Aluno("Fernando", "de Gois", "0654646046-163")

funcionario = Funcionario("Carlos", "Aberto", "26516516-166", "123")

livro = Livros("Engenharia de Software", "Paula Filho", "Estudo", "1600")

emprestimo = EmprestimoLivro(livro.isbn, livro.status)   

print("====Menu====")
print("Você é um:")
print("1 - Funcionário")
print("2 - Aluno")
opcao = int(input(" "))

if opcao == 1:
    print(f"Você é o Funcionário: {funcionario.nome} {funcionario.sobrenome}, CPF: {funcionario.cpf}, RA: {funcionario._RA}\n") 
    escolha = int(input("1 - Sim 2 - Não"))
    if escolha == 1:
        print("Função em construção...")
        exit()
    elif escolha == 2:
        print("Cadastro em construção...")
        exit()
    else:
        print("Opção inválida!")
elif opcao == 2:
    print(f"Você é o Aluno: {aluno.nome} {aluno.sobrenome}, CPF: {aluno.cpf}")
    escolha = int(input("1 - Sim 2 - Não "))
    if escolha == 1:
        print("========Bem Vindo ao sistema de biblioteca!========")
        print("Gostaria de:")
        print("1 - Emprestar Livro")
        print("2 - Devolver Livro")
        opcao1 = int(input(" "))
        if opcao1 == 1:
            emprestimo.emprestar()
            print(f"Livro '{livro.titulo}' emprestado para {aluno.nome}")
        elif opcao1 == 2:
            emprestimo.devolver()
            print(f"Livro '{livro.titulo}' devolvido por {aluno.nome}")
        else:
            print("Opção invalida!")
    elif escolha == 2:
        print("Cadastro em construção...")
        exit()
    else:
        print("Opção inválida!")
else:
    print("Opção inválida!")

